//
//  PQCgenKAT_sign.c
//
//  Created by Bassham, Lawrence E (Fed) on 8/29/17.
//  Copyright © 2017 Bassham, Lawrence E (Fed). All rights reserved.
//
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "rng.h"
#include "sign.h"

#define	MAX_MARKER_LEN      50

#define KAT_SUCCESS          0
#define KAT_FILE_OPEN_ERROR -1
#define KAT_DATA_ERROR      -3
#define KAT_CRYPTO_FAILURE  -4

void
fprintBstr(FILE *fp, char *s, unsigned char *a, unsigned long long l)
{
	unsigned long long  i;
 
	fprintf(fp, "%s", s);

	for ( i=0; i<l; i++ )
		fprintf(fp, "%02X", a[i]);

	if ( l == 0 )
		fprintf(fp, "00");

	fprintf(fp, "\n");
}
int main(){
    char                fn_req[32], fn_rsp[32];
    FILE                *fp_req, *fp_rsp;
    uint8_t             seed[48];
    uint8_t             msg[3300];
    uint8_t             entropy_input[48];
    uint8_t             *m, *sm, *m1;
    size_t              mlen, smlen, mlen1;
    int                 count;
    int                 done;
    uint8_t             pk[CRYPTO_PUBLICKEYBYTES], sk[CRYPTO_SECRETKEYBYTES];
    int                 ret_val;

    sprintf(fn_rsp, "PQCsignKAT_%.16s.rsp", CRYPTO_ALGNAME);
    if ( (fp_rsp = fopen(fn_rsp, "w")) == NULL ) {
        printf("Couldn't open <%s> for write\n", fn_rsp);
        return KAT_FILE_OPEN_ERROR;
    }
    //for (int i =0; i<4;i++){
    if ( (ret_val = crypto_sign_keypair(pk, sk)) != 0) {
        printf("crypto_sign_keypair returned <%d>\n", ret_val);
        return KAT_CRYPTO_FAILURE;
    }
    //}
    m = (uint8_t *)calloc(mlen, sizeof(uint8_t));
    m1 = (uint8_t *)calloc(mlen+CRYPTO_BYTES, sizeof(uint8_t));
    sm = (uint8_t *)calloc(mlen+CRYPTO_BYTES, sizeof(uint8_t));
    if ( (ret_val = crypto_sign(sm, &smlen, m, mlen, sk)) != 0) {
            printf("crypto_sign returned <%d>\n", ret_val);
            return KAT_CRYPTO_FAILURE;
    }

    printf("\n%d", crypto_sign_verify(sm, smlen, m, mlen, pk));
    
    // fprintBstr(fp_rsp, "pk = ", pk, CRYPTO_PUBLICKEYBYTES);
    // fprintBstr(fp_rsp, "sk = ", sk, CRYPTO_SECRETKEYBYTES);
    // fclose(fp_rsp);
    return 0;
}